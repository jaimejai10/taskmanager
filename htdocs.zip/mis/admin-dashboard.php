<?php
session_start();
require_once __DIR__ . "/../DB_connection.php";

// MIS Head-only dashboard. Uses the existing PDO connection variable: $conn.
if (empty($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit;
}
$accessRole = strtolower(trim((string)($_SESSION['access_role'] ?? '')));
$sessionRole = strtolower(trim((string)($_SESSION['role'] ?? '')));
if ($accessRole !== 'admin' && $sessionRole !== 'mishead') {
    http_response_code(403);

    require __DIR__ . '/access-denied.php';

    exit;
}
if (empty($_SESSION['admin_csrf'])) $_SESSION['admin_csrf'] = bin2hex(random_bytes(32));
$csrf = $_SESSION['admin_csrf'];
$success = '';
$error = '';
function h($v): string
{
    return htmlspecialchars((string)($v ?? ''), ENT_QUOTES, 'UTF-8');
}
function countTasks(PDO $conn, ?string $status = null): int
{
    if ($status === null) return (int)$conn->query('SELECT COUNT(*) FROM tasks')->fetchColumn();
    $s = $conn->prepare('SELECT COUNT(*) FROM tasks WHERE LOWER(TRIM(status)) = LOWER(TRIM(:status))');
    $s->execute(['status' => $status]);
    return (int)$s->fetchColumn();
}

// Save edits and reassignment from the modal.
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'update_task') {
    if (!hash_equals($csrf, (string)($_POST['csrf_token'] ?? ''))) $error = 'Session token invalid. Refresh the page and try again.';
    else {
        $taskId = filter_input(INPUT_POST, 'task_id', FILTER_VALIDATE_INT);
        $title = trim((string)($_POST['title'] ?? ''));
        $category = trim((string)($_POST['category'] ?? ''));
        $description = trim((string)($_POST['description'] ?? ''));
        $priority = trim((string)($_POST['priority'] ?? 'Medium'));
        $status = trim((string)($_POST['status'] ?? 'Pending'));
        $dueDate = trim((string)($_POST['due_date'] ?? ''));
        $assignedId = trim((string)($_POST['assigned_id'] ?? ''));
        if (
            !$taskId || $title === '' || $category === '' || $description === '' ||
            !in_array($status, ['Pending', 'Assigned', 'In Progress', 'On Hold', 'Completed', 'Cancelled'], true) ||
            !in_array($priority, ['Low', 'Medium', 'High', 'Urgent'], true)
        ) $error = 'Please complete all required fields with valid values.';
        else try {
            if ($assignedId !== '') {
                $u = $conn->prepare("SELECT user_id FROM users WHERE user_id = :id AND LOWER(TRIM(role)) = 'it associate' LIMIT 1");
                $u->execute(['id' => $assignedId]);
                if (!$u->fetchColumn()) throw new RuntimeException('Select a valid IT Associate.');
            }
            $t = $conn->prepare('SELECT task_id FROM tasks WHERE task_id = :id LIMIT 1');
            $t->execute(['id' => $taskId]);
            if (!$t->fetchColumn()) throw new RuntimeException('Task not found.');
            $q = $conn->prepare('UPDATE tasks SET title=:title, category=:category, description=:description, priority=:priority, status=:status, due_date=:due_date, assigned_id=:assigned_id, updated_at=NOW() WHERE task_id=:task_id');
            $q->execute(['title' => $title, 'category' => $category, 'description' => $description, 'priority' => $priority, 'status' => $status, 'due_date' => $dueDate !== '' ? $dueDate : null, 'assigned_id' => $assignedId !== '' ? $assignedId : null, 'task_id' => $taskId]);
            $success = 'Task updated successfully.';
        } catch (Throwable $e) {
            $error = $e instanceof RuntimeException ? $e->getMessage() : 'Unable to update task. Check the database column names against your schema.';
        }
    }
}
$total = countTasks($conn);
$pending = countTasks($conn, 'Pending');
$completed = countTasks($conn, 'Completed');
$cancelled = countTasks($conn, 'Cancelled');
$period = $_GET['period'] ?? 'month';
if ($period === 'week') $dateFilter = ' AND created_at >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)';
elseif ($period === 'year') $dateFilter = ' AND created_at >= DATE_SUB(CURDATE(), INTERVAL 1 YEAR)';
else {
    $period = 'month';
    $dateFilter = " AND created_at >= DATE_FORMAT(CURDATE(), '%Y-%m-01')";
}
$statusRows = $conn->query("SELECT status, COUNT(*) total FROM tasks WHERE status IS NOT NULL $dateFilter GROUP BY status")->fetchAll(PDO::FETCH_ASSOC);
$statusTotals = ['Pending' => 0, 'In Progress' => 0, 'Completed' => 0, 'Cancelled' => 0];
foreach ($statusRows as $r) {
    $k = trim((string)$r['status']);
    if (isset($statusTotals[$k])) $statusTotals[$k] = (int)$r['total'];
}
$categories = $conn->query("SELECT COALESCE(NULLIF(TRIM(category),''),'Uncategorized') category_name, COUNT(*) total FROM tasks WHERE 1=1 $dateFilter GROUP BY COALESCE(NULLIF(TRIM(category),''),'Uncategorized') ORDER BY total DESC LIMIT 5")->fetchAll(PDO::FETCH_ASSOC);
$maxCategory = 1;
foreach ($categories as $c) $maxCategory = max($maxCategory, (int)$c['total']);
$productivity = $conn->query("SELECT u.user_id,u.full_name,SUM(CASE WHEN LOWER(TRIM(t.status)) IN ('assigned','pending') THEN 1 ELSE 0 END) assigned_count,SUM(CASE WHEN LOWER(TRIM(t.status))='in progress' THEN 1 ELSE 0 END) in_progress_count,SUM(CASE WHEN LOWER(TRIM(t.status))='completed' THEN 1 ELSE 0 END) completed_count,COUNT(t.task_id) total_count FROM users u LEFT JOIN tasks t ON t.assigned_id=u.user_id WHERE LOWER(TRIM(u.role))='it associate' GROUP BY u.user_id,u.full_name ORDER BY completed_count DESC,total_count DESC LIMIT 6")->fetchAll(PDO::FETCH_ASSOC);
$upcoming = $conn->query("SELECT t.task_id,t.report_id,t.title,t.status,t.due_date,c.comp_name,u.full_name assignee_name FROM tasks t LEFT JOIN companies c ON c.comp_id=t.company_id LEFT JOIN users u ON u.user_id=t.assigned_id WHERE t.due_date IS NOT NULL AND t.due_date >= CURDATE() AND LOWER(TRIM(COALESCE(t.status,''))) NOT IN ('completed','cancelled') ORDER BY t.due_date LIMIT 5")->fetchAll(PDO::FETCH_ASSOC);
$recent = $conn->query('SELECT t.*,c.comp_name,u.full_name assignee_name FROM tasks t LEFT JOIN companies c ON c.comp_id=t.company_id LEFT JOIN users u ON u.user_id=t.assigned_id ORDER BY t.created_at DESC LIMIT 8')->fetchAll(PDO::FETCH_ASSOC);
$associates = $conn->query("SELECT user_id,full_name FROM users WHERE LOWER(TRIM(role))='it associate' ORDER BY full_name")->fetchAll(PDO::FETCH_ASSOC);
$userName = $_SESSION['full_name'] ?? $_SESSION['username'] ?? 'MIS Head';
    $initials = strtoupper(substr($userName, 0, 1));
    $layoutRole = 'admin';
    $currentPage = 'dashboard';
    $roleLabel = 'MIS HEAD';
    $portalLabel = 'Admin Portal';
?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>MIS Helpdesk | Admin Dashboard</title>
    <link rel="stylesheet" href="../css/admin-dashboard.css">
</head>

<body>
    <div class="app-shell">
        <?php require __DIR__ . '/../includes/sidebar.php'; ?>
<main class="main-area">
            <?php require __DIR__ . '/../includes/header.php'; ?>
<section class="dashboard-content">
                <?php if ($success): ?><div class="alert success"><?= h($success) ?></div><?php endif; ?><?php if ($error): ?><div class="alert error"><?= h($error) ?></div><?php endif; ?>
                <section class="stat-grid"><a class="stat-card blue" href="admin-requests.php"><span class="stat-icon">▤</span><span><strong><?= $total ?></strong><small>Total Requests</small></span><b>›</b></a><a class="stat-card amber" href="admin-requests.php?status=Pending"><span class="stat-icon">◷</span><span><strong><?= $pending ?></strong><small>Pending Requests</small></span><b>›</b></a><a class="stat-card green" href="admin-requests.php?status=Completed"><span class="stat-icon">✓</span><span><strong><?= $completed ?></strong><small>Completed Requests</small></span><b>›</b></a><a class="stat-card red" href="admin-requests.php?status=Cancelled"><span class="stat-icon">×</span><span><strong><?= $cancelled ?></strong><small>Cancelled Requests</small></span><b>›</b></a></section>
                <section class="two-col">
                    <article class="panel">
                        <div class="panel-heading">
                            <h2>Request Overview</h2>
                            <form method="get"><select name="period" onchange="this.form.submit()">
                                    <option value="week" <?= $period === 'week' ? 'selected' : '' ?>>Last 7 Days</option>
                                    <option value="month" <?= $period === 'month' ? 'selected' : '' ?>>This Month</option>
                                    <option value="year" <?= $period === 'year' ? 'selected' : '' ?>>Last Year</option>
                                </select></form>
                        </div>
                        <div class="bar-chart"><?php $bars = [['Pending', $statusTotals['Pending'], 'amber'], ['In Progress', $statusTotals['In Progress'], 'green'], ['Completed', $statusTotals['Completed'], 'blue'], ['Cancelled', $statusTotals['Cancelled'], 'red']];
                                                $maxBar = 1;
                                                foreach ($bars as $b) $maxBar = max($maxBar, $b[1]);
                                                foreach ($bars as $b): ?><div class="bar-column"><strong><?= $b[1] ?></strong>
                                    <div class="bar-track">
                                        <div class="bar <?= $b[2] ?>" style="height:<?= max(5, round($b[1] / $maxBar * 100)) ?>%"></div>
                                    </div><span><?= h($b[0]) ?></span>
                                </div><?php endforeach; ?></div>
                    </article>
                    <article class="panel">
                        <div class="panel-heading">
                            <h2>Top Requested Problems</h2><span class="subtle"><?= h(['week' => 'Last 7 Days', 'month' => 'This Month', 'year' => 'Last Year'][$period]) ?></span>
                        </div>
                        <div class="problem-list"><?php if (!$categories): ?><p class="empty-state">No categories found for this period.</p><?php endif; ?><?php foreach ($categories as $i => $c): ?><div class="problem-row"><span><?= h($c['category_name']) ?></span>
                                    <div class="problem-track">
                                        <div class="problem-fill color-<?= ($i % 5) + 1 ?>" style="width:<?= round($c['total'] / $maxCategory * 100) ?>%"></div>
                                    </div><strong><?= $c['total'] ?></strong>
                                </div><?php endforeach; ?></div>
                    </article>
                </section>
                <section class="two-col">
                    <article class="panel">
                        <div class="panel-heading">
                            <h2>IT Associates Productivity</h2><span class="subtle">All-time totals</span>
                        </div>
                        <div class="table-wrap">
                            <table>
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>IT Associate</th>
                                        <th>Assigned</th>
                                        <th>In Progress</th>
                                        <th>Completed</th>
                                        <th>Completion Rate</th>
                                    </tr>
                                </thead>
                                <tbody><?php if (!$productivity): ?><tr>
                                            <td colspan="6" class="empty-cell">No IT Associates found.</td>
                                        </tr><?php endif; ?><?php foreach ($productivity as $i => $p): $rate = $p['total_count'] ? round($p['completed_count'] / $p['total_count'] * 100) : 0; ?><tr>
                                            <td><?= $i + 1 ?></td>
                                            <td class="person-cell"><?= h($p['full_name']) ?></td>
                                            <td><?= $p['assigned_count'] ?></td>
                                            <td><?= $p['in_progress_count'] ?></td>
                                            <td><?= $p['completed_count'] ?></td>
                                            <td>
                                                <div class="rate-cell"><span><?= $rate ?>%</span>
                                                    <div class="rate-track">
                                                        <div style="width:<?= $rate ?>%"></div>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr><?php endforeach; ?></tbody>
                            </table>
                        </div>
                    </article>
                    <article class="panel">
                        <div class="panel-heading">
                            <h2>Upcoming Tasks</h2><a href="admin-requests.php">View All</a>
                        </div>
                        <div class="upcoming-list"><?php if (!$upcoming): ?><p class="empty-state">No upcoming tasks with due dates.</p><?php endif; ?><?php foreach ($upcoming as $t): ?><div class="upcoming-item">
                                    <div class="date-tile"><small><?= h(date('M', strtotime($t['due_date']))) ?></small><strong><?= h(date('d', strtotime($t['due_date']))) ?></strong></div>
                                    <div class="upcoming-detail"><strong><?= h($t['title']) ?></strong><small><?= h($t['comp_name'] ?? 'No company') ?></small><small>Assigned: <?= h($t['assignee_name'] ?? 'Unassigned') ?></small></div><span class="status status-<?= h(strtolower(str_replace(' ', '-', (string)$t['status']))) ?>"><?= h($t['status']) ?></span>
                                </div><?php endforeach; ?></div>
                    </article>
                </section>
                <section class="bottom-grid">
                    <article class="panel">
                        <div class="panel-heading">
                            <h2>Requests by Category</h2>
                        </div>
                        <div class="category-summary">
                            <div class="donut">
                                <div><strong><?= array_sum(array_map(fn($c) => (int)$c['total'], $categories)) ?></strong><small>Requests</small></div>
                            </div>
                            <div class="legend"><?php $colors = ['#2d91f8', '#20bf91', '#ffbd35', '#f04444', '#8550ed'];
                                                foreach ($categories as $i => $c): ?><div><i style="background:<?= $colors[$i % 5] ?>"></i><span><?= h($c['category_name']) ?></span><b><?= $c['total'] ?></b></div><?php endforeach; ?><?php if (!$categories): ?><span class="subtle">No data available.</span><?php endif; ?></div>
                        </div>
                    </article>
                    <article class="panel recent-panel">
                        <div class="panel-heading">
                            <h2>Recent IT Requests</h2><a href="admin-requests.php">View All</a>
                        </div>
                        <div class="table-wrap">
                            <table>
                                <thead>
                                    <tr>
                                        <th>Report No.</th>
                                        <th>Title</th>
                                        <th>Company</th>
                                        <th>Assigned To</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody><?php if (!$recent): ?><tr>
                                            <td colspan="6" class="empty-cell">No requests found.</td>
                                        </tr><?php endif; ?><?php foreach ($recent as $t): ?><tr>
                                            <td><?= h($t['report_id']) ?></td>
                                            <td class="request-title"><?= h($t['title']) ?></td>
                                            <td><?= h($t['comp_name'] ?? '—') ?></td>
                                            <td><?= h($t['assignee_name'] ?? 'Unassigned') ?></td>
                                            <td><span class="status status-<?= h(strtolower(str_replace(' ', '-', (string)$t['status']))) ?>"><?= h($t['status']) ?></span></td>
                                            <td><button type="button" class="edit-button" data-task="<?= h(json_encode(['task_id' => $t['task_id'], 'report_id' => $t['report_id'], 'title' => $t['title'], 'category' => $t['category'], 'description' => $t['description'] ?? '', 'priority' => $t['priority'] ?? 'Medium', 'status' => $t['status'], 'due_date' => $t['due_date'] ?? '', 'assigned_id' => $t['assigned_id'] ?? ''], JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_TAG | JSON_HEX_AMP)) ?>">Edit / Reassign</button></td>
                                        </tr><?php endforeach; ?></tbody>
                            </table>
                        </div>
                    </article>
                    <article class="panel quick-panel">
                        <div class="panel-heading">
                            <h2>Quick Actions</h2>
                        </div><a class="quick-action blue" href="admin-requests.php">▤<strong>View All<br>IT Requests</strong></a><a class="quick-action green" href="admin-reports.php">▥<strong>Generate<br>Reports</strong></a><a class="quick-action purple" href="admin-associates.php">♙<strong>Manage<br>IT Associates</strong></a><a class="quick-action amber" href="admin-requests.php?unassigned=1">↗<strong>Assign Unassigned<br>Tasks</strong></a>
                    </article>
                </section>
            </section>
        </main>
    </div>
    <dialog id="editDialog" class="edit-dialog">
        <form method="post" class="edit-form">
            <div class="dialog-heading">
                <div><small>ADMIN TASK MANAGEMENT</small>
                    <h2>Edit / Reassign Task</h2>
                    <p>Report No. <strong id="modalReportNo"></strong></p>
                </div><button type="button" class="close-dialog" id="closeDialog">×</button>
            </div><input type="hidden" name="action" value="update_task"><input type="hidden" name="csrf_token" value="<?= h($csrf) ?>"><input type="hidden" name="task_id" id="modalTaskId"><label>Request Title<input name="title" id="modalTitle" maxlength="200" required></label><label>Category<select name="category" id="modalCategory" required><?php foreach (['Network', 'Printer', 'Hardware', 'Software', 'Email', 'Internet', 'Account', 'CCTV', 'Maintenance', 'Device', 'Others'] as $c): ?><option><?= h($c) ?></option><?php endforeach; ?></select></label><label>Description<textarea name="description" id="modalDescription" rows="3" required></textarea></label>
            <div class="form-two"><label>Priority<select name="priority" id="modalPriority"><?php foreach (['Low', 'Medium', 'High', 'Urgent'] as $v): ?><option><?= h($v) ?></option><?php endforeach; ?></select></label><label>Status<select name="status" id="modalStatus"><?php foreach (['Pending', 'Assigned', 'In Progress', 'On Hold', 'Completed', 'Cancelled'] as $v): ?><option><?= h($v) ?></option><?php endforeach; ?></select></label></div>
            <div class="form-two"><label>Due Date<input type="date" name="due_date" id="modalDueDate"></label><label>Reassign to IT Associate<select name="assigned_id" id="modalAssigned">
                        <option value="">Unassigned</option><?php foreach ($associates as $a): ?><option value="<?= h($a['user_id']) ?>"><?= h($a['full_name']) ?></option><?php endforeach; ?>
                    </select></label></div>
            <div class="dialog-actions"><button type="button" class="secondary-button" id="cancelDialog">Cancel</button><button class="save-button" type="submit">Save Changes</button></div>
        </form>
    </dialog>
    <script>
        const dialog = document.getElementById('editDialog');
        document.querySelectorAll('.edit-button').forEach(b => b.addEventListener('click', () => {
            const t = JSON.parse(b.dataset.task);
            for (const [id, key] of [
                    ['modalTaskId', 'task_id'],
                    ['modalReportNo', 'report_id'],
                    ['modalTitle', 'title'],
                    ['modalCategory', 'category'],
                    ['modalDescription', 'description'],
                    ['modalPriority', 'priority'],
                    ['modalStatus', 'status'],
                    ['modalDueDate', 'due_date'],
                    ['modalAssigned', 'assigned_id']
                ]) {
                const e = document.getElementById(id);
                if (e.tagName === 'STRONG') e.textContent = t[key] ?? '';
                else e.value = t[key] ?? '';
            }
            dialog.showModal();
        }));

        function closeDialog() {
            dialog.close()
        }
        document.getElementById('closeDialog').addEventListener('click', closeDialog);
        document.getElementById('cancelDialog').addEventListener('click', closeDialog);
    </script>
<?php require __DIR__ . '/../includes/footer.php'; ?>